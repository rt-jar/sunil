package com.upgrad.patterns.Constants;

public enum SourceType {
    DiseaseSh,
    JohnHopkins
}
